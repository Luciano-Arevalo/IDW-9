##  Punto 2) En el archivo cliente.py, se genera la clase correspondiente al diagrama 
##     de clases del enunciado del trabajo final integrador. 
class Cliente:

    def __init__(self, numero_id, nombres, apellidos, email):
        self.__numero_id = numero_id
        self.__nombres = nombres
        self.__apellidos = apellidos
        self.__email = email

    def establecer_numero_id(self, numero_id):
        self.__numero_id = numero_id

    def establecer_nombres(self, nombres):
        self.__nombres = nombres

    def establecer_apellidos(self, apellidos):
        self.__apellidos = apellidos

    def establecer_email(self, email):
        self.__email = email

    def obtener_numero_id(self):
        return self.__numero_id

    def obtener_nombres(self):
        return self.__nombres

    def obtener_apellidos(self):
        return self.__apellidos

    def obtener_email(self):
        return self.__email

    ## Punto 5) Se codifica el metodo __eq__ segun el enunciado del trabajo final integrador.
    def __eq__(self, other):
        if isinstance(other, Cliente):
            return self.__numero_id == other.__numero_id
        return False

    ## Punto 5) Se codifica el metodo __str__ segun el enunciado del trabajo final integrador.
    def __str__(self):
        return f"Numero de Cliente: {self.__numero_id}, Nombres: {self.__nombres}, Apellidos: {self.__apellidos}, Email: {self.__email}"

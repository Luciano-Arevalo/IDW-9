import vehiculo


class Moto(vehiculo.Vehiculo):

    def __init__(
        self, numero_id, marca, modelo, anio, sucursal_id, estado_id, cilindrada
    ):
        super().__init__(numero_id, marca, modelo, anio, sucursal_id, estado_id)
        self.__cilindrada = cilindrada

    def establecer_cilindrada(self, cilindrada):
        self.__cilindrada = cilindrada

    def obtener_cilindrada(self):
        return self.__cilindrada

    ## Punto 5) Se codifica el metodo __str__ segun el enunciado del trabajo final integrador.
    def __str__(self):
        return (f"Numero de Moto: {self.obtener_numero_id()}, Marca: {self.obtener_marca()}, "
                f"Modelo: {self.obtener_modelo()}, Anio: {self.obtener_anio()}, "
                f"Numero de sucursal: {self.obtener_sucursal_id()}, Estado: {self.obtener_estado_id()}, "
                f"Cilindrada: {self.__cilindrada} ")
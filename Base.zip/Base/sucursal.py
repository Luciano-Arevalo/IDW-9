##  Punto 1) En el archivo sucursal.py, se genera la clase correspondiente al diagrama 
##     de clases del enunciado del trabajo final integrador. 
class Sucursal:

    def __init__(self, numero_id, direccion):
        self.__numero_id = numero_id
        self.__direccion = direccion
        self.__ventas = []

    def establecer_numero_id(self, numero_id):
        self.__numero_id = numero_id

    def establecer_direccion(self, direccion):
        self.__direccion = direccion

    def agregar_venta(self, venta):
        self.__ventas.append(venta)

    def remover_venta(self, venta):
        self.__ventas.remove(venta)

    def obtener_numero_id(self):
        return self.__numero_id

    def obtener_direccion(self):
        return self.__direccion

    def obtener_ventas(self):
        return self.__ventas

    ## Punto 5) Se codifica el metodo __eq__ segun el enunciado del trabajo final integrador.
    def __eq__(self, other):
        if isinstance(other, Sucursal):
            return self.__numero_id == other.__numero_id
        return False

    ## Punto 5) Se codifica el metodo __str__ segun el enunciado del trabajo final integrador.
    def __str__(self):
        ventas_str = "\n    ".join(str(venta) for venta in self.__ventas) if self.__ventas else "Sin ventas"
        return f"Numero de Sucursal: {self.__numero_id}, Direccion: {self.__direccion}, Ventas: \n    {ventas_str}\n "

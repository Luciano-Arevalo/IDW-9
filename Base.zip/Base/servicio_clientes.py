## Punto 6) en el archivo servicio_clientes.py se implementa el metodo 
#           obtenerTotalVentasPorCliente de acuerdo al enunciado del 
#           trabajo final integrador.

import servicio_concesionarias


class ServicioClientes:

    def obtener_total_ventas_por_cliente(self, concesionaria_id, cliente_id):

        # Aqui se obtine la consesionaria por su ID
        servicio = servicio_concesionarias.ServicioConcesionarias()
        concesionaria = servicio.obtener_por_id(concesionaria_id)
        
        # En caso de que no exista se retorna cero
        if concesionaria is None:
            return 0
        
        # se verifica si el cliente en cuestion existe en la consesionaria
        cliente_existe = False
        for cliente in concesionaria.obtener_clientes():
            if cliente.obtener_numero_id() == int(cliente_id):
                cliente_existe = True
                break
        
        # en el casso de uqe el cliente no exista se retorna cero 
        if not cliente_existe:
            return 0
        
        # suma de los montos de todas las ventas realizadas al cliente indicado 
        # en la concesionaria indicada.
        total = 0
        for sucursal in concesionaria.obtener_sucursales():
            for venta in sucursal.obtener_ventas():
                if venta.obtener_cliente_id() == int(cliente_id):
                    total += venta.obtener_monto()
        
        return f"Monto Total de ventas al cliente numero {cliente_id} de la Concesionaria numero {concesionaria_id}: " + str(total)
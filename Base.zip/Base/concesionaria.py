class Concesionaria:

    def __init__(self, numero_id, nombre):
        self.__numero_id = numero_id
        self.__nombre = nombre
        self.__clientes = []
        self.__sucursales = []
        self.__vehiculos = []

    def establecer_numero_id(self, numero_id):
        self.__numero_id = numero_id

    def establecer_nombre(self, nombre):
        self.__nombre = nombre

    def agregar_cliente(self, cliente):
        self.__clientes.append(cliente)

    def remover_cliente(self, cliente):
        self.__clientes.remove(cliente)

    def agregar_sucursal(self, sucursal):
        self.__sucursales.append(sucursal)

    def remover_sucursal(self, sucursal):
        self.__sucursales.remove(sucursal)

    def agregar_vehiculo(self, vehiculo):
        self.__vehiculos.append(vehiculo)

    def remover_vehiculo(self, vehiculo):
        self.__vehiculos.remove(vehiculo)

    def obtener_numero_id(self):
        return self.__numero_id

    def obtener_nombre(self):
        return self.__nombre

    def obtener_clientes(self):
        return self.__clientes

    def obtener_sucursales(self):
        return self.__sucursales

    def obtener_vehiculos(self):
        return self.__vehiculos

    ## Punto 5) Se codifica el metodo __eq__ segun el enunciado del trabajo final integrador.
    def __eq__(self, other):
        if isinstance(other, Concesionaria):
            return self.__numero_id == other.__numero_id
        return False

    ## Punto 5) Se codifica el metodo __str__ segun el enunciado del trabajo final integrador.
    def __str__(self):
        clientes_str = "\n  ".join(str(cliente) for cliente in self.__clientes) if self.__clientes else "Sin clientes"
        sucursales_str = "\n  ".join(str(sucursal) for sucursal in self.__sucursales) if self.__sucursales else "Sin sucursales"
        vehiculos_str = "\n  ".join(str(vehiculo) for vehiculo in self.__vehiculos) if self.__vehiculos else "Sin vehículos"
        
        return (f"Concesionaria numero: {self.__numero_id}, Nombre: {self.__nombre}  "
                f"\nClientes:\n  {clientes_str}\n  "
                f"\nSucursales:\n  {sucursales_str}\n  "
                f"\nVehiculos:\n  {vehiculos_str}\n  ")
## Integrantes del Grupo R:

## Diego Joaquin Colina
## Guadalupe Cristina Chalup
## Enzo Leiva

## Punto 7) en el archivo servicio_vehiculos.py se implementa el metodo 
#           obtenerVehiculosPorSucursalYEstado de acuerdo al enunciado del 
#           trabajo final integrador.

import servicio_concesionarias


class ServicioVehiculos:

    def obtener_vehiculos_por_sucursal_y_estado(self, concesionaria_id, sucursal_id, estado_id):

        # Aqui se obtiene la consesionaria por su ID
        servicio = servicio_concesionarias.ServicioConcesionarias()
        concesionaria = servicio.obtener_por_id(concesionaria_id)
        
        # si no existe retornamos una lista vacia
        if concesionaria is None:
            return []
        
        # Aqui verificamos si la sucursal existe en la concesionaria
        sucursal_existe = False
        for sucursal in concesionaria.obtener_sucursales():
            if sucursal.obtener_numero_id() == int(sucursal_id):
                sucursal_existe = True
                break
        
        # si no existe retornamos una lista vacia
        if not sucursal_existe:
            return []
        
        # aqui filltramos los vehiculos por su sucursal y su estado
        vehiculos_filtrados = []
        for vehiculo in concesionaria.obtener_vehiculos():
            if (vehiculo.obtener_sucursal_id() == int(sucursal_id) and 
                vehiculo.obtener_estado_id() == int(estado_id)):
                vehiculos_filtrados.append(vehiculo)
        
        return vehiculos_filtrados

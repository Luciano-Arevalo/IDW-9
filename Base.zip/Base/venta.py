## Punto 4) En el archivo venta.py, se genera la clase correspondiente al diagrama
##     de clases del enunciado del trabajo final integrador.

class Venta:

    def __init__(self, numero_id, fecha, cliente_id, vehiculo_id, monto):
        self.__numero_id = numero_id
        self.__fecha = fecha
        self.__cliente_id = cliente_id
        self.__vehiculo_id = vehiculo_id
        self.__monto = monto

    def establecer_numero_id(self, numero_id):
        self.__numero_id = numero_id

    def establecer_fecha(self, fecha):
        self.__fecha = fecha

    def establecer_cliente_id(self, cliente_id):
        self.__cliente_id = cliente_id

    def establecer_vehiculo_id(self, vehiculo_id):
        self.__vehiculo_id = vehiculo_id

    def establecer_monto(self, monto):
        self.__monto = monto

    def obtener_numero_id(self):
        return self.__numero_id

    def obtener_fecha(self):
        return self.__fecha

    def obtener_cliente_id(self):
        return self.__cliente_id

    def obtener_vehiculo_id(self):
        return self.__vehiculo_id

    def obtener_monto(self):
        return self.__monto

    ## Punto 5) Se codifica el metodo __eq__ segun el enunciado del trabajo final integrador.
    def __eq__(self, other):
        if isinstance(other, Venta):
            return self.__numero_id == other.__numero_id
        return False

    ## Punto 5) Se codifica el metodo __str__ segun el enunciado del trabajo final integrador.
    def __str__(self):
        return (f"Numero de venta: {self.__numero_id}, Fecha: {self.__fecha}, "
                f"Numero de cliente: {self.__cliente_id}, Numero de vehiculo: {self.__vehiculo_id}, "
                f"Monto: {self.__monto}")
